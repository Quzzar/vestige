Vestige apparatus flat-top revision, October 3, 2026.
All three models have continuous solid offering slabs.
Heights: Spellstone 12/16 block; Stone Pedestal 9/16; Runic Pedestal 7/16.
Diamond and Amethyst side motifs are set into carved recesses.
The assets directory contains Java block/item model JSON with vanilla Minecraft texture IDs.
Recipe authoring is unchanged from the owner-supplied grids and assumes one block per craft.
Block/item registration, item display and station operations remain future implementation.
See docs/design/apparatus-models.md in Vestige for the current brief and preview renders.
