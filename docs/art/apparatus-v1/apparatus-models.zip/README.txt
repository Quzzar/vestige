Vestige apparatus first model pass, October 3, 2026.
The assets directory contains Java block/item model JSON with vanilla Minecraft texture IDs.
Recipe JSON under authoring is preserved for later integration and assumes one block output per craft.
Models require corresponding block/item registration to place/use them in-game.
See docs/design/apparatus-models.md and docs/design/material-crafting.md in the Vestige repository.
