Vestige apparatus pedestal revision, October 3, 2026.
Heights: Spellstone 12/16 block; Stone Pedestal 9/16; Runic Pedestal 7/16.
Pedestals have slim paneled columns, Amethyst rosettes and stepped stone caps/feet.
Runic Pedestal has four flush pale-cyan symbols around its stone offering surface.
Models are Java block/item JSON and use vanilla texture references.
Recipe authoring retains the selected grids and assumes one block output per craft.
Runtime block/item registration, item display and station operations remain future implementation.
See docs/design/apparatus-models.md for the current brief and renders.
